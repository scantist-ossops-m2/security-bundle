<?php

namespace Symfony\Bundle\SecurityBundle\Tests\Functional\Bundle\SecuredPageBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SecuredPageBundle extends Bundle
{
}
